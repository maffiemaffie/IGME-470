let capture;
let tracker;
let lines;

// background images
let redBrick;
let whiteBrick;

const PRESSURE_THRESHOLD = 0.5;
let isSpraying = false;

// load images
function preload() {
  redBrick = loadImage('red-brick-wall.jpg');
  whiteBrick = loadImage('white-brick-wall.jpg');
}

function setup() {
  createCanvas(640, 480);
  capture = createCapture(VIDEO);
  capture.size(150, 150);

  tracker = new Tracker();
  lines = new LinesDrawer();

  colorMode(HSB);
  noStroke();
  strokeWeight(2);
  fill(0, 0, 0);
}

function draw() {
  background(220);
  image(redBrick, 0, 0, width, height);

  // mirror image
  scale(-1, 1);
    
  noStroke();
  fill(0, 0, 0);
  lines.drawLines();
  console.log(lines);

  tracker.analyzeCapture(capture);
  
  // calibrate
  if (millis() < 5000) {
    scale(-1, 1);
    textAlign(CENTER, CENTER);
    text("calibrating...", width / 2, height / 2);
    scale(-1, 1);
    return;
  }

  const canPosition = tracker.getCanPosition();

  if (Number.isNaN(canPosition.x) || Number.isNaN(canPosition.y)) return;

  const pressure = tracker.getCanPressure();

  if (isSpraying) {
    // is spraying but shouldn't be anymore
    if (pressure < PRESSURE_THRESHOLD) {
      isSpraying = false;
      lines.endLine();
      return;
    }

    // draw paint
    lines.addPoint({
      x: -width + canPosition.x,
      y: canPosition.y,
      t: frameCount,
      size: map(pressure, PRESSURE_THRESHOLD, 1, 5, 35),
    });
  } else {
    // not spraying but should be
    if (pressure > PRESSURE_THRESHOLD) {
      isSpraying = true;
      lines.startLine();
      lines.addPoint({
        x: -width + canPosition.x,
        y: canPosition.y,
        t: frameCount,
        size: map(pressure, PRESSURE_THRESHOLD, 1, 5, 35),
      });
      return;
    }

    // draw cursor
    noFill();
    stroke(0, 0, 100);
    circle(-width + canPosition.x, canPosition.y, 15);
  }
}
