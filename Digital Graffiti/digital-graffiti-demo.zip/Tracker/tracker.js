class Tracker {
  // brightest pixels from the last frame
  constructor() {
    this.lastFrame = [];
    this.hueMin = 360;
    this.hueMax = 0;
  }

  // convert capture to array of pixel data
  convertCaptureToPixels(capture) {
    const pixelObjects = [];
    capture.loadPixels();

    for (let row = 0; row < capture.height; row++) {
      for (let column = 0; column < capture.width; column++) {
        const pixelIndex = 4 * (row * capture.width + column);

        const r = capture.pixels[pixelIndex + 0];
        const g = capture.pixels[pixelIndex + 1];
        const b = capture.pixels[pixelIndex + 2];

        colorMode(RGB);
        const c = color(r, g, b);
        colorMode(HSB);

        pixelObjects.push({
          x: column * (width / capture.width),
          y: row * (height / capture.height),
          h: hue(c),
          s: saturation(c),
          b: brightness(c),
        });
      }
    }

    return pixelObjects;
  }

  // select brightest pixels in the image
  getBrightest(pixelsToSearch, howMany) {
    // filter out any dim pixels
    const filtered = pixelsToSearch.filter(
      (pixel) => pixel.b > 75 && pixel.s > 50
    );

    // move most saturated pixels to the top
    const sorted = filtered.sort((pixelA, pixelB) => pixelB.s - pixelA.s);

    // select the most saturated pixels
    return sorted.slice(0, howMany);
  }

  // analyze the current frame
  analyzeCapture(capture) {
    const capturePixels = this.convertCaptureToPixels(capture);

    this.lastFrame = this.getBrightest(capturePixels, 25);
    
    for (const { h } of this.lastFrame) {
      if (h > this.hueMax) this.hueMax = h;
      if (h < this.hueMin) this.hueMin = h;
    }
  }

  // use analysis to find can position
  getCanPosition() {
    let averageX = 0;
    let averageY = 0;
    let weightedTotal = 0;

    for (const { x, y, s, b } of this.lastFrame) {
      const weight = s * b;
      averageX += x * weight;
      averageY += y * weight;
      weightedTotal += weight;
    }

    averageX /= weightedTotal;
    averageY /= weightedTotal;

    return {
      x: averageX,
      y: averageY,
    };
  }

  // use analysis to find out can cap pressure
  getCanPressure() {
    let averageHue = 0;
    let weightedTotal = 0;

    for (const { h, s, b } of this.lastFrame) {
      const weight = s * b;
      averageHue += h * weight;
      weightedTotal += weight;
    }

    averageHue /= weightedTotal;

    const normalizedHue = map(averageHue, this.hueMin, this.hueMax, 0, 1, true);
    
    if (Number.isNaN(normalizedHue)) return 0;

    return normalizedHue;
  }
}
