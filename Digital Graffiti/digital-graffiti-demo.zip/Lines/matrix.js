// old rref calculator from an old personal project

function loadEmptyMatrix(rows, cols) {
  const emptyMatrix = [];
  for (let row = 0; row < rows; row++) {
    emptyMatrix.push(Array(cols).fill(0));
  }
  return emptyMatrix;
}


const forEachEntry = (
  matrix,
  callback
) => {
  if (matrix.length === 0) {
    throw new Error('matrix is empty');
  }
  if (matrix.some((row) => row.length === 0)) {
    throw new Error('matrix has no columns');
  }

  for (let row = 0; row < matrix.length; row++) {
    for (let col = 0; col < matrix[0].length; col++) {
      callback(matrix[row][col], row, col);
    }
  }
};

const cloneMatrix = (matrix) => {
  let clone = loadEmptyMatrix(matrix.length, matrix[0].length)
  forEachEntry(matrix, (entry, row, column) => {
    clone[row][column] = entry;
  });
  return clone;
};

const changeMatrixSize = (
  matrix,
  rows,
  columns
) => {
  const newMatrix = loadEmptyMatrix(rows, columns);

  forEachEntry(newMatrix, (_, row, col) => {
    newMatrix[row][col] = matrix[row]?.[col] ?? 0;
  });

  return newMatrix;
};

const unflattenMatrix = (
  flatMatrix,
  rows,
  columns
) => {
  if (rows * columns !== flatMatrix.length) {
    throw new Error('matrix/dimensions size mismatch');
  }
  const unflattenedMatrix = loadEmptyMatrix(rows, columns);

  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < columns; col++) {
      unflattenedMatrix[row][col] = flatMatrix.shift(); // we checked at the beginning
    }
  }
  return unflattenedMatrix;
};

const swapRows = (
  matrix,
  row1,
  row2
) => {
  if (matrix.length === 0) {
    throw new Error('matrix is empty');
  }
  if (row1 >= matrix.length || row2 >= matrix.length) {
    throw new Error('one or both rows not in matrix');
  }

  const swappedMatrix = loadEmptyMatrix(matrix.length, matrix[0].length);

  for (let row = 0; row < matrix.length; row++) {
    if (row === row1) {
      // if row 1, swap with row 2
      swappedMatrix[row] = [...matrix[row2]];
      continue;
    }
    if (row === row2) {
      // if row 2, swap with row 1
      swappedMatrix[row] = [...matrix[row1]];
      continue;
    }
    swappedMatrix[row] = [...matrix[row]]; // add row as normal
  }
  return swappedMatrix;
};

const scaleRow = (
  matrix,
  scaleRow,
  scalar
) => {
  if (matrix.length === 0) {
    throw new Error('matrix is empty');
  }
  if (scaleRow >= matrix.length) {
    throw new Error('row not in matrix');
  }

  const scaledMatrix = loadEmptyMatrix(matrix.length, matrix[0].length);
  forEachEntry(matrix, (entry, row, col) => {
    if (row === scaleRow) {
      scaledMatrix[row][col] = entry * scalar;
      return;
    }
    scaledMatrix[row][col] = entry;
  });

  return scaledMatrix;
};

const addScaledRow = (
  matrix,
  addendRow,
  addedTo,
  scalar
) => {
  if (matrix.length === 0) {
    throw new Error('matrix is empty');
  }
  if (addendRow >= matrix.length || addedTo >= matrix.length) {
    throw new Error('one or both rows not in matrix');
  }

  const summedMatrix = loadEmptyMatrix(matrix.length, matrix[0].length);
  forEachEntry(matrix, (entry, row, col) => {
    if (row === addedTo) {
      summedMatrix[row][col] = entry + matrix[addendRow][col] * scalar;
      return;
    }
    summedMatrix[row][col] = entry;
  });

  return summedMatrix;
};

const RREF = (matrix) => reducedRowEchelonForm(matrix);
const reducedRowEchelonForm = (matrix) => {
  if (matrix.length === 0) {
    throw new Error('matrix is empty');
  }
  if (matrix.some((row) => row.length === 0)) {
    throw new Error('matrix has no columns');
  }

  const isZero = (n) => {
    const EPSILON = 1e-12;
    return Math.abs(n) < EPSILON;
  }

  let RREFmatrix = cloneMatrix(matrix);

  let pivotRow = 0;
  for (
    let col = 0;
    col < RREFmatrix[0].length && pivotRow < RREFmatrix.length;
    col++
  ) {
    let pivotFound = !isZero(RREFmatrix[pivotRow][col]);
    // no pivot in the right place
    if (!pivotFound) {
      // find nonzero entry in this column
      for (let swap = pivotRow + 1; swap < RREFmatrix.length; swap++) {
        // swap future pivot into place
        if (!isZero(RREFmatrix[swap][col])) {
          RREFmatrix = swapRows(RREFmatrix, pivotRow, swap);
          pivotFound = true;
          break;
        }
      }
    }
    // no potential pivots in this column
    if (!pivotFound) continue;
    // potential pivot found
    RREFmatrix = scaleRow(RREFmatrix, pivotRow, 1 / RREFmatrix[pivotRow][col]);
    // zero the rest of the column
    for (let row = 0; row < RREFmatrix.length; row++) {
      if (row === pivotRow) continue;
      RREFmatrix = addScaledRow(
        RREFmatrix,
        pivotRow,
        row,
        -RREFmatrix[row][col]
      );
    }
    pivotRow++;
  }

  return RREFmatrix;
};