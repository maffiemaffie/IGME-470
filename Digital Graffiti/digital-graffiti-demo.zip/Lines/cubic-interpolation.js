// gets slope between two points
function getSlope(t1, x1, t3, x3) {
  return (x3 - x1) / (t3 - t1);
}

// gets coefficients of interpolation polynomial
function getInterpolationCoefficients(t1, x1, t2, x2, t3, x3, t4, x4) {
  const matrix = [[], [], [], []];
  matrix[0][0] = t2 * t2 * t2;
  matrix[0][1] = t2 * t2;
  matrix[0][2] = t2;
  matrix[0][3] = 1;

  matrix[1][0] = t3 * t3 * t3;
  matrix[1][1] = t3 * t3;
  matrix[1][2] = t3;
  matrix[1][3] = 1;

  matrix[2][0] = 3 * t2 * t2;
  matrix[2][1] = 2 * t2;
  matrix[2][2] = 1;
  matrix[2][3] = 0;

  matrix[3][0] = 3 * t3 * t3;
  matrix[3][1] = 2 * t3;
  matrix[3][2] = 1;
  matrix[3][3] = 0;
  
  matrix[0][4] = x2;
  matrix[1][4] = x3;
  matrix[2][4] = getSlope(t1, x1, t3, x3);
  matrix[3][4] = getSlope(t2, x2, t4, x4);

  const rref = RREF(matrix);

  const a = rref[0][4];
  const b = rref[1][4];
  const c = rref[2][4];
  const d = rref[3][4];

  return { a, b, c, d };
}

// interpolate between points using pregenerated coefficients
function getInterpolatedValueAt(t, coefficients) {
  const { a, b, c, d } = coefficients;

  return a * t * t * t + b * t * t + c * t + d;
}
