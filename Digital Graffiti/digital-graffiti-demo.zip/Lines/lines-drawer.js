// draws multiple lines with interpolation
class LinesDrawer {
  constructor() {
    this.lines = [];
    this.currentLine = null;
  }

  // create a new line to add points to
  startLine() {
    const newLine = [];
    this.currentLine = newLine;
    this.lines.push(newLine);
  }

  // stop adding points to the current line
  endLine() {
    this.currentLine = null;
  }

  // add a point to the current line
  addPoint({ x, y, size, t }) {
    if (this.currentLine === null) return;
    this.currentLine.push({ x, y, size, t });
  }

  // gets coefficients for the interpolated polynomial
  getCoefficientsForPoints(p1, p2, p3, p4) {
    const x1 = p1.x;
    const x2 = p2.x;
    const x3 = p3.x;
    const x4 = p4.x;

    const y1 = p1.y;
    const y2 = p2.y;
    const y3 = p3.y;
    const y4 = p4.y;

    const size1 = p1.size;
    const size2 = p2.size;
    const size3 = p3.size;
    const size4 = p4.size;

    const t1 = p1.t;
    const t2 = p2.t;
    const t3 = p3.t;
    const t4 = p4.t;

    const xCoefficients = getInterpolationCoefficients(
      t1,
      x1,
      t2,
      x2,
      t3,
      x3,
      t4,
      x4
    );

    const yCoefficients = getInterpolationCoefficients(
      t1,
      y1,
      t2,
      y2,
      t3,
      y3,
      t4,
      y4
    );

    const sizeCoefficients = getInterpolationCoefficients(
      t1,
      size1,
      t2,
      size2,
      t3,
      size3,
      t4,
      size4
    );

    return {
      x: xCoefficients,
      y: yCoefficients,
      size: sizeCoefficients,
    };
  }

  // draw a line of points
  drawLine(line) {
    if (line.length < 4) return;

    for (let i = 1; i < line.length - 2; i++) {
      const p1 = line[i - 1];
      const p2 = line[i + 0];
      const p3 = line[i + 1];
      const p4 = line[i + 2];

      const coefficients = this.getCoefficientsForPoints(p1, p2, p3, p4);

      // evenly spaced dots
      for (let t = 0; t < 1; t += 2.5 / dist(p2.x, p2.y, p3.x, p3.y)) {
        const interpolatedX = getInterpolatedValueAt(
          map(t, 0, 1, p2.t, p3.t),
          coefficients.x
        );
        const interpolatedY = getInterpolatedValueAt(
          map(t, 0, 1, p2.t, p3.t),
          coefficients.y
        );
        const interpolatedSize = getInterpolatedValueAt(
          map(t, 0, 1, p2.t, p3.t),
          coefficients.size
        );

        circle(interpolatedX, interpolatedY, interpolatedSize);
      }
    }
  }

  drawLines() {
    for (const line of this.lines) {
      this.drawLine(line);
    }
  }
}
